package com.mycompany.proyectofinal;

import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class logica extends javax.swing.JFrame {
//variables globales
    double ventas[][];
    String[] nombres_m;
    String[] nombres_t;
    int f, c;
    int filaActual = 1;
    int columnaActual = 1;
    double promedio;
    double acumulado;
    double venta_baja;
    double venta_alta;
    double[] acumulado_c;
    double[] acumulado_f;
    
    
    public void guardarResultados(String nombreArchivo) {
    try (FileWriter file = new FileWriter(nombreArchivo)) {
        // Escribe los resultados en el archivo
        file.write(txtaresultado.getText());
        System.out.println("Resultados guardados en el archivo: " + nombreArchivo);
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    //Metodo Json
    private JSONArray convertirMatrizAJSON(double[][] matriz) {
        JSONArray matrizJSON = new JSONArray();

        for (int i = 0; i < f; i++) {
            JSONArray filaJSON = new JSONArray();
            for (int j = 0; j < c; j++) {
                filaJSON.add(matriz[i][j]);
            }
            matrizJSON.add(filaJSON);
        }

        return matrizJSON;
    }
    //paso como parametros todos los vectores y variables donde se encuentran lo resultados
    public void escribirJSON(double[][] ventas, String[] nombres_m, String[] nombres_c,
            int f, int c, double promedio, double acumulado,
            double venta_baja, double venta_alta, double[] acumulado_c,
            double[] acumulado_f,double calcularPromedioColumna,double calcularPromedioFila) {

        JSONArray matrizJSON = convertirMatrizAJSON(ventas);
        //informacion de la matriz
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("filas", f);
        jsonObject.put("columnas", c);
        jsonObject.put("matriz", matrizJSON);
        
        //acumuladoa
        jsonObject.put("acumuladoTotalVentas", acumulado);
        JSONArray acumuladoPorTiendas = new JSONArray();
        for (int j = 0; j < f; j++) {
            JSONObject productoJSON = new JSONObject();
            productoJSON.put("tiendas", nombres_c[j]);
            productoJSON.put("acumulado", acumulado_f[j]);
            acumuladoPorTiendas.add(productoJSON);
        }
         jsonObject.put("acumuladoPorTiendas", acumuladoPorTiendas);
         JSONArray acumuladoPorMes = new JSONArray();
        for (int i = 0; i < c; i++) {
            JSONObject mesJSON = new JSONObject();
            mesJSON.put("mes", nombres_m[i]);
            mesJSON.put("acumulado", acumulado_c[i]);
            acumuladoPorMes.add(mesJSON);
        }
        jsonObject.put("acumuladoPorMes", acumuladoPorMes);    
        jsonObject.put("promedioTiendas", calcularPromedioFila);
        
        //promedios
        jsonObject.put("promedioMes", calcularPromedioColumna);
        
        jsonObject.put("promedioVentas", promedio);
        
        jsonObject.put("ventaMasBaja", venta_baja);
        jsonObject.put("ventaMasAlta", venta_alta);

        //libreia Gson para formato legible
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String jsonFormatted = gson.toJson(jsonObject);
        // Escribir el JSON en un archivo llamado "ventas_resultados.json"
        try ( FileWriter file = new FileWriter("ventas_resultados.json")) {
            file.write(jsonFormatted);
            System.out.println("JSON escrito en el archivo 'ventas_resultados.json'");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public logica() {
        initComponents();
        //Validaciones de Ingreso de filas y columnas 
        while (true) {
            try {
                String filas = JOptionPane.showInputDialog("Ingrese el número de filas:");
                if (filas == null) {
                    System.exit(0);
                }
                f = Integer.parseInt(filas);
                nombres_t = new String[f];
                break;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido para las filas.");
            }
        }

        while (true) {
            try {
                String columnas = JOptionPane.showInputDialog("Ingrese el número de columnas:");
                if (columnas == null) {
                    System.exit(0);
                }
                c = Integer.parseInt(columnas);
                nombres_m = new String[c];
                break;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido para las columnas.");
            }
        }
        //se inicializan los vectores con f y c
        ventas = new double[f][c];
        acumulado_c = new double[c];
        acumulado_f = new double[f];
    }
    //Metdodo para acu general
    public double acumularMatriz(double[][] matriz) {
        double acu = 0;
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                acu = acu + matriz[i][j];
            }
        }
        return acu;
    }
    //Acumular por columnas
    public double[] acumularPorColumnas(double[][] matriz) {
    double[] acumuladoColumnas = new double[c];

    for (int j = 0; j < c; j++) {
        double acu = 0;
        for (int i = 0; i < f; i++) {
            acu = acu + matriz[i][j];
        }
        acumuladoColumnas[j] = acu;
    }

    return acumuladoColumnas;
}

        //Acumular por filas
   public double[] acumularPorFilas(double[][] matriz) {
    double[] acumuladoFilas = new double[f];

    for (int i = 0; i < f; i++) {
        double acu = 0;
        for (int j = 0; j < c; j++) {
            acu = acu + matriz[i][j];
        }
        acumuladoFilas[i] = acu;
    }

    return acumuladoFilas;
}

//Promedio general
    public double calcularPromedio(double[][] matriz) {
        int con = 0;
        double pro, acu = 0;
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                acu += matriz[i][j];
                con++;
            }

        }

        pro = acu / con;
        return pro;

    }
    //Promedio por filas
    public double calcularPromedioFila(double[][] matriz) {
    double pro, acu = 0;
    int con = 0;
    for (int i = 0; i < f; i++) {
        for (int j = 0; j < c; j++) {
            acu += matriz[i][j];  
            con++;
        }
    }
    pro = acu / f;
    return pro;
}
//Promedio por columnas
    public double calcularPromedioColumna(double[][] matriz) {
    double pro, acu = 0;
    int con = 0;
    for (int j = 0; j < c; j++) {
        for (int i = 0; i < f; i++) {
            acu += matriz[i][j];  
            con++;
        }
    }
    pro = acu / c;
    return pro;
}

    //Calcular el valor mas alto
    public double calcularMasalto(double matriz[][]) {
        double v_alto = 0;
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                if (i == 0 && j == 0) {
                    v_alto = matriz[i][j];
                } else if (matriz[i][j] > v_alto) {
                    v_alto = matriz[i][j];

                }
            }
        }
        return v_alto;

    }
    //Calcular el valor mas bajo
    public double calcularMasbajo(double matriz[][]) {
        double v_bajo = 0;
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                if (i == 0 && j == 0) {
                    v_bajo = matriz[i][j];
                } else if (matriz[i][j] < v_bajo) {
                    v_bajo = matriz[i][j];

                }
            }
        }
        return v_bajo;

    }
    //Imprimir matriz en btnmostrarmatriz
    public static void imprimirMatriz(double matriz[][]) {
        int filas = matriz.length;
        int columnas = matriz[0].length;

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                JOptionPane.showMessageDialog(null, "[" + matriz[i][j] + "]" + "\n");
            }

        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lbltitulo = new javax.swing.JLabel();
        txttiendas = new javax.swing.JTextField();
        txtventas = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtaresultado = new javax.swing.JTextArea();
        txtindice = new javax.swing.JTextField();
        lblfila = new javax.swing.JLabel();
        lblcolumna = new javax.swing.JLabel();
        txtcolumna = new javax.swing.JTextField();
        lblcomida = new javax.swing.JLabel();
        lblmes = new javax.swing.JLabel();
        lblmatriz = new javax.swing.JLabel();
        btnvectores = new javax.swing.JButton();
        btnmatriz = new javax.swing.JButton();
        btnsiguiente = new javax.swing.JButton();
        btnayuda = new javax.swing.JButton();
        btnvermatriz = new javax.swing.JButton();
        txtmeses = new javax.swing.JTextField();
        btnventas = new javax.swing.JButton();
        btnsalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        lbltitulo.setFont(new java.awt.Font("Lucida Bright", 0, 18)); // NOI18N
        lbltitulo.setForeground(new java.awt.Color(0, 0, 0));
        lbltitulo.setText("COMIDAS RAPIDAS");

        txttiendas.setBackground(new java.awt.Color(255, 255, 255));
        txttiendas.setForeground(new java.awt.Color(0, 0, 0));

        txtventas.setBackground(new java.awt.Color(255, 255, 255));
        txtventas.setForeground(new java.awt.Color(0, 0, 0));

        txtaresultado.setBackground(new java.awt.Color(255, 255, 255));
        txtaresultado.setColumns(20);
        txtaresultado.setForeground(new java.awt.Color(0, 0, 0));
        txtaresultado.setRows(5);
        jScrollPane1.setViewportView(txtaresultado);

        txtindice.setEditable(false);
        txtindice.setBackground(new java.awt.Color(255, 255, 255));
        txtindice.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        txtindice.setForeground(new java.awt.Color(0, 0, 0));
        txtindice.setText("1");
        txtindice.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblfila.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        lblfila.setForeground(new java.awt.Color(0, 0, 0));
        lblfila.setText("Fila");

        lblcolumna.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        lblcolumna.setForeground(new java.awt.Color(0, 0, 0));
        lblcolumna.setText("Columna");

        txtcolumna.setEditable(false);
        txtcolumna.setBackground(new java.awt.Color(255, 255, 255));
        txtcolumna.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        txtcolumna.setForeground(new java.awt.Color(0, 0, 0));
        txtcolumna.setText("1");
        txtcolumna.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblcomida.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        lblcomida.setForeground(new java.awt.Color(0, 0, 0));
        lblcomida.setText("Ingresa el nombre de la tienda en la posicion 1");

        lblmes.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        lblmes.setForeground(new java.awt.Color(0, 0, 0));
        lblmes.setText("Ingresa el mes en la posicion 1");

        lblmatriz.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        lblmatriz.setForeground(new java.awt.Color(0, 0, 0));

        btnvectores.setBackground(new java.awt.Color(51, 51, 255));
        btnvectores.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        btnvectores.setForeground(new java.awt.Color(255, 255, 255));
        btnvectores.setText("agregar valor");
        btnvectores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnvectoresActionPerformed(evt);
            }
        });

        btnmatriz.setBackground(new java.awt.Color(51, 51, 255));
        btnmatriz.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        btnmatriz.setForeground(new java.awt.Color(255, 255, 255));
        btnmatriz.setText("Agregar a matriz");
        btnmatriz.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnmatriz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmatrizActionPerformed(evt);
            }
        });

        btnsiguiente.setBackground(new java.awt.Color(51, 51, 255));
        btnsiguiente.setForeground(new java.awt.Color(255, 255, 255));
        btnsiguiente.setText(">>");
        btnsiguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsiguienteActionPerformed(evt);
            }
        });

        btnayuda.setBackground(new java.awt.Color(51, 51, 255));
        btnayuda.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        btnayuda.setForeground(new java.awt.Color(255, 255, 255));
        btnayuda.setText("Ayuda");
        btnayuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnayudaActionPerformed(evt);
            }
        });

        btnvermatriz.setBackground(new java.awt.Color(51, 51, 255));
        btnvermatriz.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        btnvermatriz.setForeground(new java.awt.Color(255, 255, 255));
        btnvermatriz.setText("ver matriz");
        btnvermatriz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnvermatrizActionPerformed(evt);
            }
        });

        txtmeses.setBackground(new java.awt.Color(255, 255, 255));
        txtmeses.setForeground(new java.awt.Color(0, 0, 0));

        btnventas.setBackground(new java.awt.Color(51, 51, 255));
        btnventas.setFont(new java.awt.Font("Lucida Bright", 1, 12)); // NOI18N
        btnventas.setForeground(new java.awt.Color(255, 255, 255));
        btnventas.setText("Calcular ventas");
        btnventas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnventasActionPerformed(evt);
            }
        });

        btnsalir.setBackground(new java.awt.Color(51, 51, 255));
        btnsalir.setFont(new java.awt.Font("Lucida Bright", 1, 14)); // NOI18N
        btnsalir.setText("Salir");
        btnsalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(332, 332, 332)
                .addComponent(lbltitulo)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtventas, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txttiendas, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(63, 63, 63)
                                                .addComponent(btnmatriz))))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(20, 20, 20)
                                        .addComponent(lblcomida, javax.swing.GroupLayout.PREFERRED_SIZE, 359, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(txtmeses, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(38, 38, 38)
                                        .addComponent(btnsiguiente))
                                    .addComponent(lblmes, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(lblfila, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtindice, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(220, 220, 220)
                                        .addComponent(btnvectores)
                                        .addGap(252, 252, 252)
                                        .addComponent(lblcolumna)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtcolumna, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lblmatriz, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(679, 679, 679)
                                        .addComponent(btnvermatriz)
                                        .addGap(22, 22, 22)
                                        .addComponent(btnayuda))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnventas)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(12, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnsalir)
                .addGap(24, 24, 24))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(lbltitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblmes, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblcomida, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtmeses, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txttiendas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnsiguiente))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtcolumna, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblcolumna)
                    .addComponent(txtindice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblfila, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnvectores))
                .addGap(123, 123, 123)
                .addComponent(lblmatriz, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtventas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnmatriz)
                        .addGap(137, 137, 137))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnayuda)
                            .addComponent(btnvermatriz)
                            .addComponent(btnventas))
                        .addGap(38, 38, 38)
                        .addComponent(btnsalir)
                        .addGap(70, 70, 70))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void btnvectoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnvectoresActionPerformed
        int indi = filaActual;
        int indi_c = columnaActual;

        if (indi <= f && indi_c <= c) {
            String n_tienda = txttiendas.getText().trim();
            String nombreMes = txtmeses.getText().trim();

            if (!n_tienda.isEmpty() && !nombreMes.isEmpty()) {
                nombres_t[indi - 1] = n_tienda;
                nombres_m[indi_c - 1] = nombreMes;
                lblmatriz.setText("Ingresa las ventas de la tienda " + nombres_t[indi - 1] + " en el mes " + nombres_m[indi_c - 1]);

                if (indi == f && indi_c == c) {
                    btnvectores.setEnabled(false);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese valores válidos para el nombre de la tienda y el mes.");
            }
        } else {
            btnvectores.setEnabled(false);
        }


    }//GEN-LAST:event_btnvectoresActionPerformed

    private void btnmatrizActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmatrizActionPerformed
        int indi = filaActual;
        int indi_c = columnaActual;

        if (filaActual <= f && columnaActual <= c) {
            //Si la conversión es exitosa, se asigna ese valor a la posición correspondiente en una matriz
            try {
                double valorVenta = Double.parseDouble(txtventas.getText());
                ventas[indi - 1][indi_c - 1] = valorVenta;

                JOptionPane.showMessageDialog(null, "Venta registrada en la posición [" + indi + ", " + indi_c + "]");

                txtventas.setText("");

                if (filaActual == f && columnaActual == c) {
                    btnmatriz.setEnabled(false);
                    JOptionPane.showMessageDialog(null, "Matriz completada con éxito");
                }
                //arroja un mesaje dde error si el usuario ingresa letras
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese un valor numérico válido para las ventas.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Ha excedido los límites de la matriz.");
        }

    }//GEN-LAST:event_btnmatrizActionPerformed

    private void btnsiguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsiguienteActionPerformed
        //verfica q los campos de texto no esten vacios
        String campo = txttiendas.getText();
        String campo2 = txtmeses.getText();
        if (!campo.isEmpty() && !campo2.isEmpty()) {
            //verifica q no hayan alcanzado sus limites
            if (filaActual <= f && columnaActual <= c) {
                
                if (columnaActual == c) {
                    filaActual++;
                    columnaActual = 1;
                } else {
                    columnaActual++;
                }
                //setea los indices en la posicion actual al lbl
                txtindice.setText(Integer.toString(filaActual));
                txtcolumna.setText(Integer.toString(columnaActual));
                //setea enunciados 
                lblcomida.setText("Ingresa el nombre de la tienda en la posición " + filaActual);
                lblmes.setText("Ingresa el mes en la posición: " + columnaActual);
                //se deshabilita el btn al llenarse
                if (filaActual == f && columnaActual == c) {
                    btnsiguiente.setEnabled(false);
                }
            }

        } else {
            JOptionPane.showMessageDialog(null, "Campos vacios. Por favor llene los campos");
        }

        txttiendas.setText("");
        txtmeses.setText("");


    }//GEN-LAST:event_btnsiguienteActionPerformed

    private void btnventasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnventasActionPerformed
        int indi = filaActual;
        int indi_c = columnaActual;
        double promedio = calcularPromedio(ventas);
        double acumulado = acumularMatriz(ventas);
        double venta_baja = calcularMasbajo(ventas);
        double venta_alta = calcularMasalto(ventas);
        double promediocolumna = calcularPromedioColumna(ventas);
        double promediofila = calcularPromedioFila(ventas);
        double[] acumulado_c = acumularPorColumnas(ventas);
        double[] acumulado_f = acumularPorFilas(ventas);

        txtaresultado.setText("");
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                txtaresultado.append("Las ventas de la tienda " + nombres_t[i] + " en el mes de " + nombres_m[j] + " fue de: " + ventas[i][j] + "\n");
            }
        }

        // Muestra acumulado por mes
        for (int i = 0; i < c; i++) {
            txtaresultado.append("El acumulado por mes  " + nombres_m[i] + " es: " + acumulado_c[i] + "\n");
        }
        for (int j = 0; j < f; j++) {
            txtaresultado.append("El acumulado por tienda " + nombres_t[j] + " es: " + acumulado_f[j] + "\n");
        }

        txtaresultado.append("El promedio general de ventas es : " + promedio + "\n");
        txtaresultado.append("El promedio total de ventas por meses es : " + promediocolumna + "\n");
        txtaresultado.append("El promedio total de ventas por tiendas es : " + promediofila + "\n");
        txtaresultado.append("El acumulado total de ventas  es : " + acumulado + "\n");
        txtaresultado.append("La venta más baja es: " + venta_baja + "\n");
        txtaresultado.append("La venta más alta es: " + venta_alta + "\n");
        guardarResultados("resultados.txt");
        escribirJSON(ventas, nombres_m, nombres_t, f, c, promedio, acumulado, venta_baja, venta_alta, acumulado_c, acumulado_f,promediofila,promediocolumna);


    }//GEN-LAST:event_btnventasActionPerformed

    private void btnayudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnayudaActionPerformed
        JOptionPane.showMessageDialog(null, "1. Ingresa en el campo de filas el nombre de las tiendas " + "\n"
                + "2. Ingresa en el campo de columnas los meses" + "\n"
                + "3. Presione el boton de agregar valor " + "\n"
                + "4. Ingrese las ventas obtenidas de la tienda y mes indicado oprimiendo el boton agregar a matriz" + "\n"
                + "5. para ingresar los siguientes valores presionar el boton adelante (>>).Repetir el proceso hasta completar la matriz" + "\n"
                + "6. Al completar la matriz presione el boton calcular ventas");
    }//GEN-LAST:event_btnayudaActionPerformed

    private void btnvermatrizActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnvermatrizActionPerformed

        imprimirMatriz(ventas);
    }//GEN-LAST:event_btnvermatrizActionPerformed

    private void btnsalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsalirActionPerformed
    System.exit(0);
    }//GEN-LAST:event_btnsalirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(logica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(logica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(logica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(logica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new logica().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnayuda;
    private javax.swing.JButton btnmatriz;
    private javax.swing.JButton btnsalir;
    private javax.swing.JButton btnsiguiente;
    private javax.swing.JButton btnvectores;
    private javax.swing.JButton btnventas;
    private javax.swing.JButton btnvermatriz;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblcolumna;
    private javax.swing.JLabel lblcomida;
    private javax.swing.JLabel lblfila;
    private javax.swing.JLabel lblmatriz;
    private javax.swing.JLabel lblmes;
    private javax.swing.JLabel lbltitulo;
    private javax.swing.JTextArea txtaresultado;
    private javax.swing.JTextField txtcolumna;
    private javax.swing.JTextField txtindice;
    private javax.swing.JTextField txtmeses;
    private javax.swing.JTextField txttiendas;
    private javax.swing.JTextField txtventas;
    // End of variables declaration//GEN-END:variables
}
