
package com.mycompany.proyectofinal;

public class Proyectofinal {

    public static void main(String[] args) {
    formulario nuevo = new formulario();
    nuevo.setVisible(true);
    nuevo.setLocationRelativeTo(null);
    }
}
